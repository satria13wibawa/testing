<!DOCTYPE html>
<html>

<head>
    <title>Home</title>
</head>

<body>
    <div class="row mt-4">
        <div class="col-md-7">
            <center>
                <h1>Selamat Datang!!</h1>
            </center>
        </div>
    </div>
</body>

</html>